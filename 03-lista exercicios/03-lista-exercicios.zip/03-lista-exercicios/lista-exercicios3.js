/*function aplicarDesconto(valor, desconto){
    return (valor - (valor * desconto / 100));
}
function aplicarJuros(valor, juros){
    return (valor + (valor * (juros / 100)));
}


const precoEtiqueta = 100;
const formaDePagamento = 4;

if(formaDePagamento === 1){
    console.log(aplicarDesconto(precoEtiqueta,10));
}
else if(formaDePagamento === 2){
    console.log(aplicarDesconto(precoEtiqueta,15));
}
else if(formaDePagamento === 3){
    console.log(precoEtiqueta);
}
else {
    console.log(aplicarJuros(precoEtiqueta, 10));
} 
*/




/*const numero = 5;

    if (numero % 2 === 0) {
        console.log('Número par');
    } else {
        console.log('Número ímpar');
    }

    const numero = 10;
    
    if (numero >= 10) {
        console.log('Sucesso demais!');
    }*/



    function calcularMedia(nota1, nota2) {
        const media = (nota1 + nota2) / 2;
    }

    console.log(calcularMedia(5, 5));